my_list = [1,2,3,4,5,6]
print (len(my_list))
# 6

print(my_list[2:5])
# [3,4,5]

print(my_list[:3])
# [1,2,3]

print(my_list[3:])
#[4,5,6]

print(my_list[-1])
# 6