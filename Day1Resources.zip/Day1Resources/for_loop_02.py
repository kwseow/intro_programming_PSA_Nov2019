s = "freedom"
for c in s:
  print(c,end=" ")

print("")

print(s[:4])

print(s[-3:])
