myTime = 1000
myMins = myTime // 60
mySecs = myTime % 60
print(myMins,"mins &", mySecs,"sec")
