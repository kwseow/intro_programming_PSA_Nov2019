try:
  5/0
except:
  print("error")
  
