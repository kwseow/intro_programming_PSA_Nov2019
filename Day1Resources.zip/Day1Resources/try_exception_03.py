try:
  import special_module
except ImportError:
  print("Sorry, you don't have the special_module module installed.")
  print("and this prigram relies on it.")
  print("Please install ir reconfigure special_module and try again.")
  
  
