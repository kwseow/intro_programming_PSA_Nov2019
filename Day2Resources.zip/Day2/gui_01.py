import tkinter

window = tkinter.Tk()
window.mainloop()






















