import os

for folderName, subfolders, filenames in os.walk('C:\\Users\kwseow\Downloads'):
    print('The current folder is ' + folderName +"\n")

    for subfolder in subfolders:
        print('SUBFOLDER OF ' + folderName + ': ' + subfolder)
    for filename in filenames:
        print('FILE INSIDE ' + folderName + ': '+ filename)

    print('')