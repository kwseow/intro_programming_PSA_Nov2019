import openpyxl
import csv

workbook = openpyxl.load_workbook("students_attendance.xlsx")
sheet=workbook["Sheet1"]

max_row = sheet.max_row
max_column = sheet.max_column

writerFileHandle = open("excel_ex.csv", "w", newline='')
writer1 = csv.writer(writerFileHandle)
#row1 = ["Arron","D","X","X","X","X"]

#loop through every row
for i in range(1,max_row+1):
    row=[]

    # check odd or even row
    if i % 2: #odd
        print("%d -Odd row!"%i)
    else:
        #read cell
        for j in range(1,max_column+1):
            row.append(sheet.cell(row=i, column=j).value)
        
        print(row)
        writer1.writerow(row)
            
writerFileHandle.close()

